package com.ymn.todoapp.dao;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import com.ymn.todoapp.model.LoginBean;
import com.ymn.todoapp.util.JDBCUtil;

public class LoginDao {
	public boolean validate(LoginBean loginBean) throws ClassNotFoundException, SQLException {
		boolean status = false;
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = JDBCUtil.getConnection();
		String sql = " select * from users where username = ? and password = ? ";
		conn.setAutoCommit(false);
		try (Connection connection = JDBCUtil.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection
						.prepareStatement("select * from users where username = ? and password = ? ")) {
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, loginBean.getUsername());
			stmt.setString(2, loginBean.getPassword());

			System.out.println(stmt);
			ResultSet rs = stmt.executeQuery();
			status = rs.next();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtil.printSQLException(e);
		}
		return status;

	}

	public static void printBatchUpdateException(BatchUpdateException b) {

		System.err.println("----BatchUpdateException----");
		System.err.println("SQLState:  " + b.getSQLState());
		System.err.println("Message:  " + b.getMessage());
		System.err.println("Vendor:  " + b.getErrorCode());
		System.err.print("Update counts:  ");
		int[] updateCounts = b.getUpdateCounts();

		for (int i = 0; i < updateCounts.length; i++) {
			System.err.print(updateCounts[i] + "   ");
		}
	}
}
