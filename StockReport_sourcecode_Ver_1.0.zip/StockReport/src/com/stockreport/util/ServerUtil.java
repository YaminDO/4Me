package com.stockreport.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServerUtil {

	public static void main(String args[]) throws ParseException {

		Date date1 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse("12/11/2019");
		Date date2 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse("12/14/2019");

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formatted_date1 = formatter.format(date1);
		String formatted_date2 = formatter.format(date2);

		Date d1 = formatter.parse(formatted_date1);
		Date d2 = formatter.parse(formatted_date2);

		System.out.println("date1 : " + formatter.format(date1));
		System.out.println("date2 : " + formatter.format(date2));
		if (d1.compareTo(d2) > 0) {
			System.out.println("true");
		} else if (d1.compareTo(d2) < 0) {
			System.out.println("false");
		} else if (d1.compareTo(d2) == 0) {
			System.out.println("Date1 is equal to Date2");
		} else {
			System.out.println("How to get here?");
		}
	}

	public static String stringtoDatefromat(String date) throws ParseException {

		Date date1 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse(date);
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		String formatted_date = formatter1.format(date1);

		return formatted_date;

	}

	public static boolean isValidDate(String fromdate, String todate) throws ParseException {
		boolean valid = false;
		Date date1 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse(fromdate);
		Date date2 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse(todate);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formatted_date1 = formatter.format(date1);
		String formatted_date2 = formatter.format(date2);

		Date d1 = formatter.parse(formatted_date1);
		Date d2 = formatter.parse(formatted_date2);

		System.out.println("date1 : " + formatter.format(date1));
		System.out.println("date2 : " + formatter.format(date2));
		if (d1.compareTo(d2) > 0) {
			valid = false;
			System.out.println(valid);
		} else if (date1.compareTo(date2) < 0) {
			valid = true;
			System.out.println(valid);
		} else if (date1.compareTo(date2) == 0) {

			System.out.println("Date1 is equal to Date2");
		}
		return valid;

	}

}
