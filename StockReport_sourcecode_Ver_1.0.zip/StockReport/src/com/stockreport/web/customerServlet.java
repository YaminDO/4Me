package com.stockreport.web;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.stockreport.dao.CustomerDao;
import com.stockreport.model.Customer;
import com.stockreport.util.ServerUtil;

@WebServlet("/customerServlet")
public class customerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public customerServlet() {
		super();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
		System.out.println("doPost ===>");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("doGet ===>");
			getCustomerList(request, response);
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}

	}

	private void getCustomerList(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException, ParseException {

		String todayDate = request.getParameter("todaydate");
		String formDate = request.getParameter("fromdate");
		String toDate = request.getParameter("todate");

		System.out.println("request===>" + todayDate + " " + formDate + " " + toDate);
		boolean validDate1 = ServerUtil.isValidDate(formDate, todayDate);
		boolean validDate2 = ServerUtil.isValidDate(toDate, formDate);
		System.out.println("valid dates:" + validDate1 + " and " + validDate2);
		if (validDate1 && validDate2) {
			ArrayList<Customer> customerList = CustomerDao.selectAllCustomers(todayDate, formDate, toDate);
			System.out.println("customerlist.size=>" + customerList.size());
			request.setAttribute("customerList", customerList);
			request.setAttribute("todayDate", todayDate);
			request.setAttribute("fromDate", formDate);
			request.setAttribute("toDate", toDate);
			RequestDispatcher dispatcher = request.getRequestDispatcher("customerList.jsp");
			dispatcher.forward(request, response);
		} else if (!validDate1) {
			String message = "From date must less than today date!";
			request.setAttribute("message", message);
			request.setAttribute("todayDate", todayDate);
			request.setAttribute("fromDate", formDate);
			request.setAttribute("toDate", toDate);
			RequestDispatcher dispatcher = request.getRequestDispatcher("customerList.jsp");
			dispatcher.forward(request, response);
		} else if (!validDate2) {
			String message = "To date must less than from date!";
			request.setAttribute("message", message);
			request.setAttribute("todayDate", todayDate);
			request.setAttribute("fromDate", formDate);
			request.setAttribute("toDate", toDate);
			RequestDispatcher dispatcher = request.getRequestDispatcher("customerList.jsp");
			dispatcher.forward(request, response);
		}else {
			System.out.println("Error log***");
		}

	}

}
