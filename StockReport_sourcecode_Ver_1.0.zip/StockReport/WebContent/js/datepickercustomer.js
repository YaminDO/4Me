/**
 * 2019/12/17
 */
$(function() {
		$("#todaydate").datepicker({
			beforeShowDay : $.datepicker.noWeekends
		// disable weekends
		});

	});
	$(function() {
		$("#fromdate").datepicker({
			beforeShowDay : $.datepicker.noWeekends
		// disable weekends
		});

	});
	$(function() {
		$("#todate").datepicker({
			beforeShowDay : $.datepicker.noWeekends
		// disable weekends
		});

	});