/**
 * ymn
 */
$(function() {

		$("#todaydate").datepicker({
			beforeShowDay : $.datepicker.noWeekends
		// disable weekends
		});
		var date = new Date();
		var mm = date.getMonth() + 1;
		var day = date.getDate();
		var year = date.getFullYear();
		var day1 = date.getDay();
		var todayDate = mm + '/' + day + '/' + year;
		$('#todaydate').val(todayDate);

	});
	$(function() {
		$("#fromdate").datepicker({
			beforeShowDay : $.datepicker.noWeekends
		// disable weekends
		});
		var date = new Date();
		var mm = date.getMonth() + 1;
		var day = date.getDate() - 1;

		var year = date.getFullYear();
		var day1 = date.getDay();
		var fromDate = mm + '/' + day + '/' + year;
		$('#fromdate').val(fromDate);
	});
	$(function() {

		$("#todate").datepicker({
			beforeShowDay : $.datepicker.noWeekends
		// disable weekends
		});
		var date = new Date();
		var mm = date.getMonth();
		var day = date.getDate();
		var year = date.getFullYear();
		var day1 = date.getDay();
		if (day1 == 0) {
			day = day - 1;
		}
		if (day == 1) {
			day = day - 2;
		}
		if (date.getDay() === 6 || date.getDay() === 0)
			alert('Weekend!');
		var toDate = mm + '/' + day + '/' + year;
		$('#todate').val(toDate);

	});