package com.stockreport.serverutil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServerUtil {

	public static void main(String args[]) throws ParseException {
		/*
		 * String sDate1="12/13/2019"; Date date1=(Date) new
		 * SimpleDateFormat("MM/dd/yyyy").parse(sDate1);
		 * System.out.println(sDate1+"\t"+date1);
		 * 
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); Date date2 =
		 * (Date) sdf.parse("2010-01-31");
		 * 
		 * System.out.println("date1 : " + sdf.format(date1));
		 * System.out.println("date2 : " + sdf.format(date2)); SimpleDateFormat
		 * formatter1 = new SimpleDateFormat("yyyy-MM-dd"); String formatted_date =
		 * formatter1.format(date1); System.out.println("date=>" + formatted_date);
		 */

		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); Date date1 =
		 * sdf.parse("2009-12-31"); Date date2 = sdf.parse("2010-01-31");
		 * 
		 * System.out.println("date1 : " + sdf.format(date1));
		 * System.out.println("date2 : " + sdf.format(date2));
		 * 
		 * if (date1.compareTo(date2) > 0) { System.out.println("Date1 is after Date2");
		 * } else if (date1.compareTo(date2) < 0) {
		 * System.out.println("Date1 is before Date2"); } else if
		 * (date1.compareTo(date2) == 0) {
		 * System.out.println("Date1 is equal to Date2"); } else {
		 * System.out.println("How to get here?"); }
		 */

		Date date1 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse("12/11/2019");
		Date date2 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse("12/14/2019");

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formatted_date1 = formatter.format(date1);
		String formatted_date2 = formatter.format(date2);

		Date d1 = formatter.parse(formatted_date1);
		Date d2 = formatter.parse(formatted_date2);

		System.out.println("date1 : " + formatter.format(date1));
		System.out.println("date2 : " + formatter.format(date2));
		if (d1.compareTo(d2) > 0) {
			System.out.println("true");
		} else if (d1.compareTo(d2) < 0) {
			System.out.println("false");
		} else if (d1.compareTo(d2) == 0) {
			System.out.println("Date1 is equal to Date2");
		} else {
			System.out.println("How to get here?");
		}
	}

	public static String datetoString(String date) {
		String date1 = "";
		String[] date_arr = date1.split("/");
		return date1;

	}

	public static String stringtoDatefromat(String date) throws ParseException {

		Date date1 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse(date);
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		String formatted_date = formatter1.format(date1);

		return formatted_date;

	}

	public static boolean isValidDate(String fromdate, String todate) throws ParseException {
		boolean valid = false;
		Date date1 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse(fromdate);
		Date date2 = (Date) new SimpleDateFormat("MM/dd/yyyy").parse(todate);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formatted_date1 = formatter.format(date1);
		String formatted_date2 = formatter.format(date2);

		Date d1 = formatter.parse(formatted_date1);
		Date d2 = formatter.parse(formatted_date2);

		System.out.println("date1 : " + formatter.format(date1));
		System.out.println("date2 : " + formatter.format(date2));
		if (d1.compareTo(d2) > 0) {
			valid = false;
			System.out.println(valid);
		} else if (date1.compareTo(date2) < 0) {
			valid = true;
			System.out.println(valid);
		} else if (date1.compareTo(date2) == 0) {

			System.out.println("Date1 is equal to Date2");
		}
		return valid;

	}

}
