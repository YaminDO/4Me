package com.stockreport.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import com.stockreport.model.Customer;
import com.stockreport.serverutil.ServerUtil;

public class CustomerDao {

	private static String jdbcURL = "jdbc:mysql://localhost:3306/dbstock?useSSL=false";
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "root";

	/*
	 * private static final String SELECT_ALL_CUSTOMERS =
	 * "select c.customerID,c.customerName,p.productName,e.executionDate,e.price from dbstock.customer as c,"
	 * +
	 * " dbstock.product as p, dbstock.execution as e where e.customerid = c.customerid and e.productid = p.productid"
	 * + "";
	 */
	private static String sql1 = "select  distinct e.productid ,  e.customerid  from dbstock.execution as e where e.customerid in"
			+ " (select distinct e.customerid from execution as e , customer as c where e.customerid = c.customerid and c.recordStatus=1)"
			+ "";

	public CustomerDao() {
	}

	protected static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Connection:==>" + connection);
		return connection;
	}

	public static ArrayList<Customer> selectAllCustomers() {

		ArrayList<Customer> customerList = new ArrayList<>();
		ArrayList<Customer> customerList1 = new ArrayList<>();

		try (Connection connection = getConnection();

				PreparedStatement preparedStatement = connection.prepareStatement(sql1);) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomerID(rs.getInt("customerid"));
				customer.setProductID(rs.getInt("productid"));
				customerList1.add(customer);

				/*
				 * customer.setCustomerID(rs.getInt("customerid"));
				 */
				System.out.println("***Custoemr id *****");
				System.out.println("custoemr id ===>" + rs.getInt("customerid"));
				System.out.println("product id ===>" + rs.getInt("productid"));

				System.out.println("_________________________________");
				/*
				 * sql =
				 * "select avg(price) as todaySellAVG from execution where customerid=? and recordStatus=1 and orderStatus=2 and executionDate =?"
				 * ;
				 */
				/*
				 * String sql = "select * from execution where price in(" +
				 * "select avg(price) as todaySellAVG from execution where customerid=? and recordStatus=1 and orderStatus=2 and executionDate =?"
				 * + "having todaySellAVG <(" +
				 * "select avg(price) as buyAVGprice from execution where orderStatus =1 and productid=? and executionDate <=? "
				 * + "and executionDate>=?))"; PreparedStatement stmt =
				 * connection.prepareStatement(sql); stmt.setInt(1, rs.getInt("customerid"));
				 * stmt.setString(2, "2019-12-10"); stmt.setInt(3, rs.getInt("productid"));
				 * stmt.setString(4, "2019-12-10"); stmt.setString(5, "2019-11-10"); ResultSet
				 * res = preparedStatement.executeQuery(); System.out.println("Second sql ==> "
				 * + sql);
				 * 
				 * while(res.next()) {
				 * 
				 * customer.setCustomerID(res.getInt("custoemrid"));
				 * customer.setCutomerName(getCustomerName(customer.getCustomerID(),
				 * connection)); customer.setProductName(getProudctName(res.getInt("productid"),
				 * connection)); customerList.add(customer);
				 * 
				 * }
				 */

			}
			System.out.println("***Looping***");
			System.out.println("array size==>" + customerList1.size());
			for (int i = 0; i < customerList1.size(); i++) {
				String sql = "select * from execution where price in("
						+ "select avg(price) as todaySellAVG from execution where customerid=? and recordStatus=1 and orderStatus=2 and executionDate =?"
						+ "having todaySellAVG <("
						+ "select avg(price) as buyAVGprice from execution where orderStatus =1 and productid=? and executionDate <=? "
						+ "and executionDate>=?))";
				PreparedStatement stmt = connection.prepareStatement(sql);
				stmt.setInt(1, customerList1.get(i).getCustomerID());
				stmt.setString(2, "2019-12-10");
				stmt.setInt(3, customerList1.get(i).getProductID());
				stmt.setString(4, "2019-12-10");
				stmt.setString(5, "2019-11-10");
				ResultSet res = preparedStatement.executeQuery();
				System.out.println("Second sql ==> " + sql);
				System.out.println("customerid =>" + customerList1.get(i).getCustomerID());
				System.out.println("productid =>" + customerList1.get(i).getProductID());

				/*
				 * if(rs != null) { rs.absolute(2); }
				 */

				while (res.next()) {
					Customer customer = new Customer();
					customer.setCustomerID(res.getInt("custoemrid"));
					customer.setCutomerName(getCustomerName(customer.getCustomerID(), connection));
					customer.setProductName(getProudctName(res.getInt("productid"), connection));
					customerList.add(customer);

				}

			}
		} catch (SQLException e) {
			e.fillInStackTrace();
		}

		return customerList;
	}

	private static String getProudctName(int productid, Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		String name = "";
		String sql = "select productName from product where recordStatus =1 and productid=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, productid);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			name = rs.getString("productName");
		}
		return name;
	}

	private static String getCustomerName(int productid, Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		String name = "";
		String sql = "select c.customerName from customer c, execution e where e.customerid = c.customerid and e.productid=? and orderstatus=2";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, productid);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			name = rs.getString("customerName");
		}

		return name;
	}

	public static ArrayList<Customer> selectAllCustomers(String todayDate, String fromDate, String toDate)
			throws ParseException {

		ArrayList<Customer> customerList = new ArrayList<>();
		System.out.println("say hello******" + todayDate + "and" + fromDate + "and" + toDate);
		String today = ServerUtil.stringtoDatefromat(todayDate);
		String fromdate = ServerUtil.stringtoDatefromat(fromDate);
		String todate = ServerUtil.stringtoDatefromat(toDate);

		System.out.println("Formatting dates******" + today + "and" + fromdate + "and" + todate);

		String sql = "select distinct productid from execution where  orderStatus=1";

		/*String select_sql = "select * from execution where price  in("
				+ "select avg(price) as todaySellAVG from execution where productid=? and executionDate =? and  recordStatus=1 and orderStatus=1"
				+ " having todaySellAVG <("
				+ "select avg(price) as buyAVGprice from execution where orderStatus=1 and productid=? and executionDate <=? and executionDate>=?))";
*/
		String select_sql="select e.customerid ,e.productid ,c.customername ,p.productname as productname,e.orderstatus," + 
				" avg(price*orderquantity) as todaysellavg" + 
				" from execution e, customer c, product p" + 
				" where e.productid=? and e.orderstatus=1 and e.customerid = c.customerid and e.productid= p.productid" + 
				" and e.executionDate=? group by customerid,productid,customername,productname,e.orderstatus" + 
				" having todaysellavg <" + 
				" (select avg(price*orderQuantity) from execution" + 
				"	where productid=? and orderstatus=1 and executionDate <=? and executionDate>=?)";
		try (Connection connection = getConnection();

				PreparedStatement preparedStatement = connection.prepareStatement(sql);) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				PreparedStatement stmt = connection.prepareStatement(select_sql);
				stmt.setInt(1, rs.getInt("productid"));
				stmt.setString(2, today);
				stmt.setInt(3, rs.getInt("productid"));
				stmt.setString(4, fromdate);
				stmt.setString(5, todate);
				System.out.println("product=>" + rs.getInt("productid"));
				/*
				 * stmt.setDate(3, (java.sql.Date) fromdate); stmt.setDate(4, (java.sql.Date)
				 * todate);
				 */
				System.out.println(stmt);
				ResultSet res = stmt.executeQuery();

				while (res.next()) {
					Customer customer = new Customer();
					customer.setCustomerID(getCustomerid(res.getInt("productid"),connection));
					customer.setCutomerName(getCustomerName(res.getInt("productid"),connection));
					customer.setProductName(res.getString("productname"));
					customer.setTodayDate(todayDate);
					customer.setToDate(toDate);
					customer.setFormDate(fromDate);
					customer.setAvgBuyPrice(getAVGBuyPrice(res.getInt("productid"), fromdate, todate, connection));
					customer.setAvgSellPrice(res.getDouble("todaysellavg"));
					customerList.add(customer);

				}

			}
		} catch (SQLException e) {
			e.fillInStackTrace();
		}

		return customerList;
	}

	private static int getCustomerid(int customerid, Connection conn) throws SQLException {
		int id =0;
		String sql = "select c.customerid from customer c, execution e "
				+ "where e.customerid = c.customerid and e.productid=? and orderstatus=2";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, customerid);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			id = rs.getInt("customerid");
		}
		return id;
	}

	private static double getAVGBuyPrice(int productid, String fromdate, String todate, Connection conn)
			throws SQLException {
		// TODO Auto-generated method stub
		double buyPrice = 0.0;

		String sql = "select avg(price*orderquantity) as buy_AVG_price from execution where orderStatus=1 and productid=? and"
				+ " executionDate<=? and executionDate>=? ";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, productid);
		stmt.setString(2, fromdate);
		stmt.setString(3, todate);
		System.out.println("avg query==>" + stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			buyPrice = rs.getDouble("buy_AVG_price");
		}
		System.out.println(" buy avg  price----->" + buyPrice);
		return buyPrice;
	}

	private static double getTodaySellPrice(int productid, String today, Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		double sellPrice = 0.0;
		String sql = "select avg(price) as todaySellAVG from execution where productid=? and executionDate=?"
				+ " and recordStatus=1 and orderStatus=1 ";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, productid);
		stmt.setString(2, today);
		System.out.println("avg query==>" + stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			sellPrice = rs.getDouble("todaySellAVG");
		}
		System.out.println(" today avg sell price+++>" + sellPrice);
		return sellPrice;

	}
}
