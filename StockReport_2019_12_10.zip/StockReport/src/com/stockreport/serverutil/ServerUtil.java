package com.stockreport.serverutil;

public class ServerUtil {

	public static String datetoString(String date) {
		String date1 = "";
		String[] date_arr = date1.split("-");
		return date1;
		
	}
	
	
	
}
