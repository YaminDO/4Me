package com.stockreport.model;

public class Customer {

	private int customerID;
	private int productID;
	private String cutomerName;
	private String productName;
	private String todayDate;
	private double avgSellPrice;
	private String formDate; //from execution date
	private String toDate; //to execution date
	private double avgBuyPrice;
	private String exeDate;
	
	public Customer() {}
	
	public Customer(int customerID,int productID, String cutomerName, String productName, String todayDate, double avgSellPrice,
			String formDate, String toDate, double avgBuyPrice,String exeDate) {
		super();
		this.customerID = customerID;
		this.productID = productID;
		this.cutomerName = cutomerName;
		this.productName = productName;
		this.todayDate = todayDate;
		this.avgSellPrice = avgSellPrice;
		this.formDate = formDate;
		this.toDate = toDate;
		this.avgBuyPrice = avgBuyPrice;
		this.exeDate = "";
	}
	
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCutomerName() {
		return cutomerName;
	}
	public void setCutomerName(String cutomerName) {
		this.cutomerName = cutomerName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getTodayDate() {
		return todayDate;
	}
	public void setTodayDate(String todayDate) {
		this.todayDate = todayDate;
	}
	public double getAvgSellPrice() {
		return avgSellPrice;
	}
	public void setAvgSellPrice(double avgSellPrice) {
		this.avgSellPrice = avgSellPrice;
	}
	public String getFormDate() {
		return formDate;
	}
	public void setFormDate(String formDate) {
		this.formDate = formDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public double getAvgBuyPrice() {
		return avgBuyPrice;
	}
	public void setAvgBuyPrice(double avgBuyPrice) {
		this.avgBuyPrice = avgBuyPrice;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getExeDate() {
		return exeDate;
	}

	public void setExeDate(String exeDate) {
		this.exeDate = exeDate;
	}
	
	
	
}
