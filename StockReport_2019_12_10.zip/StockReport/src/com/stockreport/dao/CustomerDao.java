package com.stockreport.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.stockreport.model.Customer;

public class CustomerDao {

	private static String jdbcURL = "jdbc:mysql://localhost:3306/dbstock?useSSL=false";
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "root";

	/*
	 * private static final String SELECT_ALL_CUSTOMERS =
	 * "select c.customerID,c.customerName,p.productName,e.executionDate,e.price from dbstock.customer as c,"
	 * +
	 * " dbstock.product as p, dbstock.execution as e where e.customerid = c.customerid and e.productid = p.productid"
	 * + "";
	 */
	private static String sql1 = "select  distinct e.productid ,  e.customerid  from dbstock.execution as e where e.customerid in"
			+ " (select distinct e.customerid from execution as e , customer as c where e.customerid = c.customerid and c.recordStatus=1)"
			+ "";

	public CustomerDao() {
	}

	protected static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Connection:==>" + connection);
		return connection;
	}

	public static ArrayList<Customer> selectAllCustomers() {

		ArrayList<Customer> customerList = new ArrayList<>();
		ArrayList<Customer> customerList1 = new ArrayList<>();

		try (Connection connection = getConnection();

				PreparedStatement preparedStatement = connection.prepareStatement(sql1);) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomerID(rs.getInt("customerid"));
				customer.setProductID(rs.getInt("productid"));
				customerList1.add(customer);

				/*
				 * customer.setCustomerID(rs.getInt("customerid"));
				 */
				System.out.println("***Custoemr id *****");
				System.out.println("custoemr id ===>" + rs.getInt("customerid"));
				System.out.println("product id ===>" + rs.getInt("productid"));

				System.out.println("_________________________________");
				/*
				 * sql =
				 * "select avg(price) as todaySellAVG from execution where customerid=? and recordStatus=1 and orderStatus=2 and executionDate =?"
				 * ;
				 */
				/*
				 * String sql = "select * from execution where price in(" +
				 * "select avg(price) as todaySellAVG from execution where customerid=? and recordStatus=1 and orderStatus=2 and executionDate =?"
				 * + "having todaySellAVG <(" +
				 * "select avg(price) as buyAVGprice from execution where orderStatus =1 and productid=? and executionDate <=? "
				 * + "and executionDate>=?))"; PreparedStatement stmt =
				 * connection.prepareStatement(sql); stmt.setInt(1, rs.getInt("customerid"));
				 * stmt.setString(2, "2019-12-10"); stmt.setInt(3, rs.getInt("productid"));
				 * stmt.setString(4, "2019-12-10"); stmt.setString(5, "2019-11-10"); ResultSet
				 * res = preparedStatement.executeQuery(); System.out.println("Second sql ==> "
				 * + sql);
				 * 
				 * while(res.next()) {
				 * 
				 * customer.setCustomerID(res.getInt("custoemrid"));
				 * customer.setCutomerName(getCustomerName(customer.getCustomerID(),
				 * connection)); customer.setProductName(getProudctName(res.getInt("productid"),
				 * connection)); customerList.add(customer);
				 * 
				 * }
				 */

			}
			System.out.println("***Looping***");
			System.out.println("array size==>" + customerList1.size());
			for (int i = 0; i < customerList1.size(); i++) {
				String sql = "select * from execution where price in("
						+ "select avg(price) as todaySellAVG from execution where customerid=? and recordStatus=1 and orderStatus=2 and executionDate =?"
						+ "having todaySellAVG <("
						+ "select avg(price) as buyAVGprice from execution where orderStatus =1 and productid=? and executionDate <=? "
						+ "and executionDate>=?))";
				PreparedStatement stmt = connection.prepareStatement(sql);
				stmt.setInt(1, customerList1.get(i).getCustomerID());
				stmt.setString(2, "2019-12-10");
				stmt.setInt(3, customerList1.get(i).getProductID());
				stmt.setString(4, "2019-12-10");
				stmt.setString(5, "2019-11-10");
				ResultSet res = preparedStatement.executeQuery();
				System.out.println("Second sql ==> " + sql);
				System.out.println("customerid =>" + customerList1.get(i).getCustomerID());
				System.out.println("productid =>" + customerList1.get(i).getProductID());

				/*
				 * if(rs != null) { rs.absolute(2); }
				 */

				while (res.next()) {
					Customer customer = new Customer();
					customer.setCustomerID(res.getInt("custoemrid"));
					customer.setCutomerName(getCustomerName(customer.getCustomerID(), connection));
					customer.setProductName(getProudctName(res.getInt("productid"), connection));
					customerList.add(customer);

				}

			}
		} catch (SQLException e) {
			e.fillInStackTrace();
		}

		return customerList;
	}

	private static String getProudctName(int productid, Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		String name = "";
		String sql = "select productName from product where recordStatus =1 and productid=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, productid);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			name = rs.getString("productName");
		}
		return name;
	}

	private static String getCustomerName(int customerID, Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		String name = "";
		String sql = "select customerName from customer where recordStatus =1 and customerid=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, customerID);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			name = rs.getString("customerName");
		}

		return name;
	}

	public static ArrayList<Customer> selectAllCustomers(String todayDate, String fromDate, String toDate) {

		ArrayList<Customer> customerList = new ArrayList<>();
		System.out.println("say hello******" + todayDate + "and" + fromDate + "and" + toDate);
		
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
	    String strDate = formatter.format(date);  
	    System.out.println("Date Format with MM/dd/yyyy : "+strDate);  
		String sql = "select * from execution";

		try (Connection connection = getConnection();

				PreparedStatement preparedStatement = connection.prepareStatement(sql);) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomerID(rs.getInt("customerID"));
				customer.setCutomerName(getCustomerName(customer.getCustomerID(), connection));
				customer.setProductName(getProudctName(rs.getInt("productid"), connection));
				date = rs.getDate("executionDate");
				 strDate = formatter.format(date);  
			    System.out.println("execution Date Format with MM/dd/yyyy : "+strDate);  
			    customer.setExeDate(strDate);
			    

				customerList.add(customer);
			}
		} catch (SQLException e) {
			e.fillInStackTrace();
		}

		return customerList;
	}
}
